# testing_utils.py (Modified for Integration Testing)

import unittest
from app import db # Must import the real db object from your Flask app setup
from your_app_config import TestConfig # A configuration class for testing

class BaseIntegrationTest(unittest.TestCase):
    """
    Base test class that connects to the real test database 
    and manages the Flask application context.
    """
    
    def setUp(self):
        # 1. Get the testing application instance (e.g., from run.py/app.py)
        # Assuming you have a function to create the app with a specific config:
        from app.app import get_app 
        self.app = get_app('testing') # 'testing' uses TestConfig from your setup
        self.app_context = self.app.app_context()
        self.app_context.push()

        # 2. Use the real SQLAlchemy session
        # This points to the real database (e.g., 'mysql://user@host/movie_munchers_test')
        db.create_all() # Create all tables defined in models.py (which uses db.Model)

        # 3. Start a transaction for test isolation
        # Bind the session to a connection and begin a transaction
        self.connection = db.engine.connect()
        self.transaction = self.connection.begin()
        self.session = db.session # Use the real session

        # 4. Mock foreign key objects (optional, but useful for clean references)
        # You can still use the MockDB structure for clean references, but now 
        # you can also insert real objects and get their IDs.
        self.db = MockDB()

    def tearDown(self):
        # 1. Rollback the transaction to discard changes made during the test
        self.session.remove()
        self.transaction.rollback()
        self.connection.close()

        # 2. Drop the tables to ensure a clean slate, or let rollback handle it
        # db.drop_all() # Only needed if you don't use the transaction/rollback method
        
        # 3. Pop the context
        self.app_context.pop()
        
    def commit_and_flush(self):
        """Now uses the real session commit/flush for the integration test."""
        self.session.commit()
        self.session.flush()

    # Assertion Helpers remain the same (they will now catch real database errors)
    def assert_raises_integrity_error(self, func, message):
        # ... this now catches real IntegrityError from the database
        with self.assertRaises(IntegrityError, msg=message):
             func()